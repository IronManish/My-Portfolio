const chapters = [
  { id: 'home', name: 'Home', scene: 'The Waterfront', hour: 'Golden hour', art: 'manish-waterfront', point: [0.22, 0.72], objective: 'Explore the portfolio' },
  {
    id: 'profile', name: 'About me', scene: 'Baywalk', hour: 'Morning', art: 'boardwalk', point: [0.33, 0.63],
    title: 'About me', lead: 'I’m Manish Biswas from Howrah, West Bengal. My background includes BPO service, automobile training and computer applications.',
    details: [
      ['Career goal', 'Team development or unit management', 'I’m looking for an entry-level role where I can build my leadership skills and support a team.'],
      ['Languages', 'Bengali, Hindi and English', 'I also completed a spoken English course in Howrah.']
    ]
  },
  {
    id: 'education', name: 'Education', scene: 'Old Town', hour: 'Late morning', art: 'school', point: [0.40, 0.41],
    title: 'School education', lead: 'Primary, secondary and higher secondary milestones in West Bengal.',
    details: [
      ['2019', 'Higher Secondary Examination', 'Howrah Vivekananda Institution · West Bengal Council of Higher Secondary Education · Overall grade C.'],
      ['2016', 'Madhyamik Pariksha', 'Howrah Vivekananda Institution · West Bengal Board of Secondary Education · Passed.'],
      ['2009–2010', 'Primary Final Examination', 'Britti Pariksha · Primary Education Development Board, West Bengal · 184/400, Second Division.']
    ]
  },
  {
    id: 'mechanics', name: 'Automobile studies', scene: 'Workshop District', hour: 'Afternoon', art: 'workshop', point: [0.53, 0.60],
    title: 'Automobile studies', lead: 'Mechanic training at Belur Math and diploma coursework in automobile engineering.',
    details: [
      ['June 2021', 'Diploma Semester 1 · Passed', 'Dr. Sudhir Chandra Sur Institute of Technology and Sports Complex · 74.7%.'],
      ['Diploma subjects', 'Engineering fundamentals', 'Engineering graphics, workshop practice, applied sciences, mathematics and English communication.'],
      ['Oct 2018 – Mar 2019', 'Automobile Mechanic', 'Ramakrishna Mission Shilpamandira Community Training Centre · two- and four-wheeler engines, transmission, suspension, brakes and steering.']
    ]
  },
  {
    id: 'skills', name: 'Skills', scene: 'Signal Alley', hour: 'Neon night', art: 'neon', point: [0.62, 0.43],
    title: 'Skills & coursework',
    details: [
      ['People skills', 'Communication', 'Spoken English and soft skills training.'],
      ['Web & code', 'Web publishing and Python', 'Web designing and publishing, introductory Python and AI coursework.'],
      ['Digital tools', 'IT tools and Google Apps', 'Computer applications coursework.'],
      ['IoT', 'Arduino and Raspberry Pi', 'Internet of Things coursework using both platforms.'],
      ['Automotive', 'Vehicle systems', 'Petrol and diesel engines, transmission, suspension, brakes and steering.']
    ]
  },
  {
    id: 'experience', name: 'Experience', scene: 'Lookout Point', hour: 'Blue hour', art: 'rooftop', point: [0.76, 0.52],
    title: 'Work experience',
    details: [
      ['Jan–Feb 2026', 'Northen IT', 'BPO service role · 2 months.']
    ]
  },
  {
    id: 'certificates', name: 'Certificates', scene: 'Harbor Lights', hour: 'Evening', art: 'waterfront', point: [0.71, 0.29],
    title: 'Certificates', lead: 'Credentials in computer applications, automobile mechanics and spoken English.',
    details: [
      ['13 Oct 2026', 'Certificate in Computer Applications', 'Ramakrishna Mission Shilpamandira Computer Centre · February–September 2026 session · Grade A.'],
      ['03 May 2019', 'Automobile Mechanic', 'Ramakrishna Mission Shilpamandira Community Training Centre · October 2018–March 2019 session.'],
      ['01 Jul 2016', 'Certificate of Merit · Spoken English', 'Computer Age, Kadamtala · Three-month communication skills course · Grade C.']
    ]
  },
  {
    id: 'events', name: 'Events', scene: 'Assembly Square', hour: 'Storm dusk', art: 'campus', point: [0.82, 0.33],
    title: 'Workshops & events', lead: 'Participation at events organized by the Automobile Engineering department at Sur Tech.',
    details: [
      ['27 Mar 2022', 'Auto Expo and Rider Meet & Greet', 'INVIGORATE 3.0 · Group B participation certificate.'],
      ['26 Mar 2022', 'Vehicle Maintenance and Safety', 'INVIGORATE 3.0 · Group workshop participation certificate.'],
      ['04 Mar 2022', 'Evolution of Engineering & Technology', 'Session on the evolution of engineering and technology and unwritten practices.']
    ]
  },
  {
    id: 'finish', name: 'Final stop', scene: 'East Pier', hour: 'Sunrise', art: 'sunrise', point: [0.88, 0.17],
    title: 'Thanks for exploring',
    details: []
  }
];
