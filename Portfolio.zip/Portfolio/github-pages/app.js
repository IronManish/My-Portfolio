'use strict';

const byId = (id) => document.getElementById(id);
const homePanel = document.querySelector('.home-panel');
const missionPanel = document.querySelector('.mission-panel');
const missionContent = byId('mission-content');
const mapDialog = byId('map-dialog');
const mapLinks = byId('map-links');
const mapCanvas = byId('minimap');
const toast = byId('toast');
const artLayers = Array.from(document.querySelectorAll('.art'));
const progress = byId('progress');
const previous = byId('previous');
const next = byId('next');
const progressKey = 'harbor-route-visited-v1';
const totalMissions = chapters.length - 1;
const clock = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
const visited = new Set();
let current = 0;
let currentArt = '';
let visibleLayer = 0;
let toastTimer;

try {
  const saved = JSON.parse(sessionStorage.getItem(progressKey) || '[]');
  const savedIds = Array.isArray(saved) ? saved : [];
  for (const chapter of chapters.slice(1)) {
    if (savedIds.includes(chapter.id)) visited.add(chapter.id);
  }
} catch {
  // The route also works when session storage is unavailable.
}

function make(tag, className, value) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (value) node.textContent = value;
  return node;
}

function chapterLink(chapter, className, label) {
  const link = make('a', className, label || chapter.name);
  link.href = '#' + chapter.id;
  return link;
}

function updateClock() {
  const now = new Date();
  byId('clock').textContent = clock.format(now);
  byId('clock').dateTime = now.toISOString();
}

function setArt(art) {
  if (art === currentArt) return;
  currentArt = art;
  visibleLayer = 1 - visibleLayer;
  const layer = artLayers[visibleLayer];
  layer.style.backgroundImage = 'url("assets/' + art + '.webp")';
  layer.classList.add('visible');
  artLayers[1 - visibleLayer].classList.remove('visible');
}

function drawMap() {
  const ctx = mapCanvas.getContext('2d');
  if (!ctx) return;
  const { width, height } = mapCanvas;
  ctx.fillStyle = '#284354';
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = '#2a2238';
  ctx.beginPath();
  ctx.moveTo(9, 0);
  ctx.lineTo(width, 0);
  ctx.lineTo(width, 81);
  ctx.bezierCurveTo(203, 86, 210, 105, 172, 113);
  ctx.bezierCurveTo(143, 119, 117, 86, 91, 102);
  ctx.bezierCurveTo(68, 112, 59, 132, 25, 140);
  ctx.lineTo(0, height);
  ctx.lineTo(0, 21);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = '#5d5168';
  ctx.lineWidth = 1;
  for (const y of [15, 29, 43, 58, 73, 88, 105]) {
    ctx.beginPath();
    ctx.moveTo(14, y + 11);
    ctx.lineTo(145, y - 9);
    ctx.lineTo(y > 80 ? 192 : 243, y - 4);
    ctx.stroke();
  }
  for (const x of [25, 46, 68, 92, 116, 140, 163, 185, 206, 230]) {
    ctx.beginPath();
    ctx.moveTo(x + 13, 4);
    ctx.lineTo(x, 54);
    ctx.lineTo(x - 14, x > 200 ? 87 : 105);
    ctx.stroke();
  }

  ctx.beginPath();
  chapters.forEach((chapter, index) => {
    const [x, y] = chapter.point;
    if (index === 0) ctx.moveTo(x * width, y * height);
    else ctx.lineTo(x * width, y * height);
  });
  ctx.strokeStyle = '#dc699c';
  ctx.lineWidth = 2.8;
  ctx.stroke();

  chapters.forEach((chapter, index) => {
    const [x, y] = chapter.point;
    const active = index === current;
    ctx.beginPath();
    ctx.arc(x * width, y * height, active ? 7 : 3.5, 0, Math.PI * 2);
    ctx.fillStyle = active ? '#ffdfc6' : visited.has(chapter.id) ? '#ff6a9f' : '#724263';
    ctx.fill();
    if (active) {
      ctx.strokeStyle = '#ff5487';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }
  });
  ctx.fillStyle = '#ffdfc6';
  ctx.font = '600 13px monospace';
  ctx.fillText('N', 13, 20);
}

function notify(message) {
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.add('active');
  toastTimer = window.setTimeout(() => {
    toast.classList.remove('active');
    toast.textContent = '';
  }, 3200);
}

async function copyPortfolio() {
  const url = new URL(location.href);
  url.hash = '';
  try {
    await navigator.clipboard.writeText(url.href);
    notify('Portfolio link copied');
  } catch {
    notify('Copy the portfolio link from the address bar');
  }
}

function openMap() {
  if (!mapDialog.open) mapDialog.showModal();
}

function renderMission(chapter) {
  const content = make('div', 'mission-content');
  const eyebrow = make('p', 'eyebrow');
  eyebrow.append(make('span'), document.createTextNode(chapter.scene + ' · ' + chapter.hour));
  const title = make('h2', '', chapter.title);
  title.id = 'mission-title';
  title.tabIndex = -1;
  content.append(eyebrow, title);
  if (chapter.lead) content.append(make('p', 'lead', chapter.lead));

  if (chapter.details.length) {
    const entries = make('ul', 'entries');
    for (const [when, name, description] of chapter.details) {
      const entry = make('li', 'entry');
      const text = make('div');
      text.append(make('h3', '', name), make('p', '', description));
      entry.append(make('span', '', when), text);
      entries.append(entry);
    }
    content.append(entries);
  }

  if (chapter.id === 'profile') {
    const portrait = make('img', 'portrait');
    portrait.src = 'assets/manish-portrait.webp';
    portrait.width = 640;
    portrait.height = 640;
    portrait.alt = 'Manish Biswas';
    content.append(portrait);
  }

  if (chapter.id === 'finish') {
    const actions = make('div', 'finish-actions');
    const map = make('button', 'finish-action', 'Open route map');
    map.type = 'button';
    map.setAttribute('aria-haspopup', 'dialog');
    map.addEventListener('click', openMap);
    actions.append(map, chapterLink(chapters[0], 'finish-action', 'Back to home'));
    if (location.protocol === 'https:') {
      const copy = make('button', 'finish-action', 'Copy link');
      copy.type = 'button';
      copy.addEventListener('click', copyPortfolio);
      actions.append(copy);
    }
    content.append(actions);
  }
  missionContent.replaceChildren(content);
  return title;
}

function refreshStats() {
  byId('score').textContent = String(visited.size * 250).padStart(4, '0');
  const filled = Math.floor(visited.size * 5 / totalMissions);
  const stars = byId('stars');
  stars.textContent = '★'.repeat(filled) + '☆'.repeat(5 - filled);
  stars.setAttribute('aria-label', filled + ' of 5 exploration stars');
  progress.setAttribute('aria-valuenow', String(visited.size));
  for (const [index, tick] of Array.from(progress.children).entries()) {
    tick.classList.toggle('done', index < visited.size);
  }
  for (const [index, item] of Array.from(mapLinks.children).entries()) {
    const link = item.firstElementChild;
    const chapter = chapters[index];
    link.lastElementChild.textContent = index === current ? 'Current stop' : visited.has(chapter.id) ? 'Explored' : chapter.hour;
    if (index === current) link.setAttribute('aria-current', 'location');
    else link.removeAttribute('aria-current');
  }
}

function setArrow(link, chapter) {
  if (chapter) {
    link.href = '#' + chapter.id;
    link.removeAttribute('aria-disabled');
  } else {
    link.removeAttribute('href');
    link.setAttribute('aria-disabled', 'true');
  }
}

function render(focusHeading = false) {
  const id = location.hash.slice(1);
  current = Math.max(0, chapters.findIndex((chapter) => chapter.id === id));
  const chapter = chapters[current];
  const firstVisit = current > 0 && !visited.has(chapter.id);
  if (firstVisit) {
    visited.add(chapter.id);
    try {
      sessionStorage.setItem(progressKey, JSON.stringify([...visited]));
    } catch {
      // The in-memory progress still works.
    }
  }
  document.body.dataset.scene = chapter.id;
  document.title = current === 0 ? 'Manish Biswas — Harbor Route' : chapter.name + ' — Manish Biswas';
  homePanel.hidden = current !== 0;
  missionPanel.hidden = current === 0;
  const heading = current === 0 ? byId('hero-title') : renderMission(chapter);
  setArt(chapter.art);
  byId('district').textContent = chapter.scene;
  byId('scene-name').textContent = chapter.scene;
  byId('scene-hour').textContent = chapter.hour;
  const nextChapter = chapters[current + 1];
  if (chapter.objective) {
    byId('objective-label').textContent = 'Current objective';
    byId('objective').textContent = chapter.objective;
  } else if (nextChapter) {
    byId('objective-label').textContent = 'Next stop';
    byId('objective').textContent = nextChapter.name;
  } else {
    byId('objective-label').textContent = 'Route end';
    byId('objective').textContent = visited.size === totalMissions ? 'All chapters explored' : 'Revisit the route';
  }
  const step = byId('step');
  step.replaceChildren(document.createTextNode(String(current + 1).padStart(2, '0') + ' '), make('span', '', '/ ' + String(chapters.length).padStart(2, '0')));
  step.setAttribute('aria-label', 'Chapter ' + (current + 1) + ' of ' + chapters.length);
  setArrow(previous, chapters[current - 1]);
  setArrow(next, nextChapter);
  refreshStats();
  drawMap();

  if (focusHeading) {
    window.scrollTo(0, 0);
    heading.focus({ preventScroll: true });
    if (firstVisit) notify('Mission passed · ' + chapter.name + ' · +250 XP');
  }
}

chapters.forEach((chapter, index) => {
  const item = make('li');
  const link = chapterLink(chapter);
  link.replaceChildren(make('span', '', String(index + 1).padStart(2, '0')), make('strong', '', chapter.name), make('small'));
  item.append(link);
  mapLinks.append(item);
});

progress.setAttribute('aria-valuemax', String(totalMissions));
for (let index = 0; index < totalMissions; index++) progress.append(make('i'));

byId('open-map').addEventListener('click', openMap);
mapDialog.querySelector('.close').addEventListener('click', () => mapDialog.close());
mapLinks.addEventListener('click', (event) => {
  if (event.target.closest('a')) mapDialog.close();
});
document.addEventListener('keydown', (event) => {
  if (event.defaultPrevented || event.altKey || event.metaKey || event.ctrlKey || mapDialog.open) return;
  const offset = { ArrowLeft: -1, ArrowRight: 1 }[event.key];
  const chapter = chapters[current + offset];
  if (chapter) {
    event.preventDefault();
    location.hash = chapter.id;
  }
});
window.addEventListener('hashchange', () => render(true));
updateClock();
window.setInterval(updateClock, 15000);
render();

window.addEventListener('load', () => {
  for (const art of new Set(chapters.map((chapter) => chapter.art))) {
    if (art === currentArt) continue;
    const preload = new Image();
    preload.src = 'assets/' + art + '.webp';
  }
}, { once: true });
